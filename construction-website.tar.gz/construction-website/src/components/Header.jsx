import { useState } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { Menu, X, Facebook, Twitter, Linkedin, Instagram, ArrowRight, Phone, Mail } from 'lucide-react'

const Header = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const location = useLocation()

  const isActive = (path) => location.pathname === path

  return (
    <header>
      {/* Top Bar */}
      <div className="bg-[#001B3D] text-white py-2 px-4">
        <div className="container mx-auto flex flex-wrap justify-between items-center text-sm">
          <div className="flex items-center space-x-6">
            <span className="flex items-center">
              <span className="text-gray-400 mr-2">Website:</span> www.example.com
            </span>
            <span className="flex items-center">
              <span className="text-gray-400 mr-2">Email:</span> example@example.com
            </span>
            <span className="flex items-center">
              <span className="text-gray-400 mr-2">Open Time:</span> 8:00 AM - 10:00 PM
            </span>
          </div>
          <div className="flex items-center space-x-4">
            <Facebook size={16} className="cursor-pointer hover:text-[#FF6B35] transition" />
            <Twitter size={16} className="cursor-pointer hover:text-[#FF6B35] transition" />
            <Linkedin size={16} className="cursor-pointer hover:text-[#FF6B35] transition" />
            <Instagram size={16} className="cursor-pointer hover:text-[#FF6B35] transition" />
          </div>
        </div>
      </div>

      {/* Navigation */}
      <nav className="bg-white shadow-md sticky top-0 z-50">
        <div className="container mx-auto px-4">
          <div className="flex justify-between items-center py-4">
            {/* Logo */}
            <Link to="/" className="flex items-center space-x-2">
              <div className="flex items-center">
                <ArrowRight className="text-[#FF6B35] w-8 h-8 rotate-180" />
                <ArrowRight className="text-[#FF6B35] w-8 h-8 -ml-4" />
              </div>
              <span className="text-[#FF6B35] text-3xl font-bold">Emuo</span>
            </Link>

            {/* Desktop Menu */}
            <div className="hidden lg:flex items-center space-x-8">
              <Link 
                to="/" 
                className={`font-medium transition ${isActive('/') ? 'text-[#FF6B35]' : 'text-gray-700 hover:text-[#FF6B35]'}`}
              >
                Home
              </Link>
              <Link 
                to="/about" 
                className={`font-medium transition ${isActive('/about') ? 'text-[#FF6B35]' : 'text-gray-700 hover:text-[#FF6B35]'}`}
              >
                About
              </Link>
              <Link 
                to="/services" 
                className={`font-medium transition ${isActive('/services') ? 'text-[#FF6B35]' : 'text-gray-700 hover:text-[#FF6B35]'}`}
              >
                Services
              </Link>
              <Link 
                to="/gallery" 
                className={`font-medium transition ${isActive('/gallery') ? 'text-[#FF6B35]' : 'text-gray-700 hover:text-[#FF6B35]'}`}
              >
                Gallery
              </Link>
              <Link 
                to="/careers" 
                className={`font-medium transition ${isActive('/careers') ? 'text-[#FF6B35]' : 'text-gray-700 hover:text-[#FF6B35]'}`}
              >
                Careers
              </Link>
              <Link 
                to="/contact" 
                className={`font-medium transition ${isActive('/contact') ? 'text-[#FF6B35]' : 'text-gray-700 hover:text-[#FF6B35]'}`}
              >
                Contact
              </Link>
              <Link 
                to="/contact" 
                className="bg-[#FF6B35] text-white px-6 py-2 rounded hover:bg-[#ff5722] transition"
              >
                Get A Quote
              </Link>
            </div>

            {/* Mobile Menu Button */}
            <button 
              className="lg:hidden text-[#001B3D]"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>

          {/* Mobile Menu */}
          {isMenuOpen && (
            <div className="lg:hidden pb-4 space-y-2">
              <Link to="/" className="block py-2 text-gray-700 hover:text-[#FF6B35]" onClick={() => setIsMenuOpen(false)}>
                Home
              </Link>
              <Link to="/about" className="block py-2 text-gray-700 hover:text-[#FF6B35]" onClick={() => setIsMenuOpen(false)}>
                About
              </Link>
              <Link to="/services" className="block py-2 text-gray-700 hover:text-[#FF6B35]" onClick={() => setIsMenuOpen(false)}>
                Services
              </Link>
              <Link to="/gallery" className="block py-2 text-gray-700 hover:text-[#FF6B35]" onClick={() => setIsMenuOpen(false)}>
                Gallery
              </Link>
              <Link to="/careers" className="block py-2 text-gray-700 hover:text-[#FF6B35]" onClick={() => setIsMenuOpen(false)}>
                Careers
              </Link>
              <Link to="/contact" className="block py-2 text-gray-700 hover:text-[#FF6B35]" onClick={() => setIsMenuOpen(false)}>
                Contact
              </Link>
              <Link 
                to="/contact" 
                className="block bg-[#FF6B35] text-white px-6 py-2 rounded mt-2 text-center"
                onClick={() => setIsMenuOpen(false)}
              >
                Get A Quote
              </Link>
            </div>
          )}
        </div>
      </nav>
    </header>
  )
}

export default Header
