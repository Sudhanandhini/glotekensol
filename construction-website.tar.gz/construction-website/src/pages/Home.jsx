import { Link } from 'react-router-dom'
import { ArrowRight, CheckCircle, Award } from 'lucide-react'

const Home = () => {
  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[600px] bg-cover bg-center" style={{
        backgroundImage: "linear-gradient(rgba(0, 27, 61, 0.7), rgba(0, 27, 61, 0.7)), url('https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=1600')"
      }}>
        <div className="container mx-auto px-4 h-full flex items-center">
          <div className="text-white max-w-2xl">
            <p className="text-[#FF6B35] mb-2 text-sm uppercase tracking-wide">Leading Construction</p>
            <h1 className="text-5xl md:text-6xl font-bold mb-4">We Are Best Builders</h1>
            <p className="text-lg mb-8 text-gray-200">
              We have been providing top-quality construction services for over two decades. Your trusted partner in building excellence.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/contact" className="bg-[#FF6B35] text-white px-8 py-3 rounded hover:bg-[#ff5722] transition font-medium">
                Get Started
              </Link>
              <button className="bg-white text-[#001B3D] px-8 py-3 rounded hover:bg-gray-100 transition font-medium flex items-center">
                <div className="w-10 h-10 bg-[#FF6B35] rounded-full flex items-center justify-center mr-3">
                  ▶
                </div>
                How We Work
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Find Section */}
      <section className="bg-[#FF6B35] py-12">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between mb-8">
            <div className="text-white mb-6 md:mb-0">
              <h3 className="text-2xl font-bold mb-2">Reliable Building</h3>
              <p className="text-sm">And Other Construction Services</p>
            </div>
            <Link to="/services" className="bg-[#001B3D] text-white px-8 py-3 rounded hover:bg-[#002447] transition font-medium">
              View All Services
            </Link>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { title: 'Design And Building', desc: 'We are a strategy design and building company providing comprehensive solutions.' },
              { title: 'Planning & Solution', desc: 'We believe in action-focused planning and innovative solutions for every project.' },
              { title: 'Trusted & Reliable', desc: 'Years of experience and countless satisfied clients make us your trusted partner.' },
              { title: 'Certified & Accredited', desc: 'All our work is certified and meets the highest industry standards.' }
            ].map((item, index) => (
              <div key={index} className="bg-white p-6 rounded shadow-lg hover:shadow-xl transition-shadow">
                <h4 className="text-[#001B3D] font-bold text-lg mb-2">{item.title}</h4>
                <p className="text-gray-600 text-sm mb-4">{item.desc}</p>
                <Link to="/services" className="bg-[#FF6B35] text-white px-4 py-2 rounded text-sm hover:bg-[#ff5722] transition inline-block">
                  Read More
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=800" 
                alt="Blueprint" 
                className="rounded-lg shadow-xl"
              />
              <div className="absolute -bottom-6 -right-6 bg-[#FF6B35] text-white p-6 rounded-lg shadow-lg">
                <div className="text-4xl font-bold">25+</div>
                <div className="text-sm">Years Experience</div>
              </div>
            </div>
            <div>
              <p className="text-[#FF6B35] mb-2 text-sm uppercase tracking-wide">About Company</p>
              <h2 className="text-4xl font-bold text-[#001B3D] mb-4">
                World's Largest And Trusted Construction Company
              </h2>
              <p className="text-gray-600 mb-6">
                There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.
              </p>
              <div className="space-y-3 mb-6">
                <div className="flex items-start">
                  <CheckCircle className="text-[#FF6B35] mr-3 mt-1 flex-shrink-0" size={20} />
                  <p className="text-gray-600">Professional and experienced construction team with decades of expertise.</p>
                </div>
                <div className="flex items-start">
                  <CheckCircle className="text-[#FF6B35] mr-3 mt-1 flex-shrink-0" size={20} />
                  <p className="text-gray-600">Quality materials and modern construction techniques for lasting results.</p>
                </div>
                <div className="flex items-start">
                  <CheckCircle className="text-[#FF6B35] mr-3 mt-1 flex-shrink-0" size={20} />
                  <p className="text-gray-600">On-time project delivery and comprehensive customer support.</p>
                </div>
              </div>
              <Link to="/about" className="bg-[#001B3D] text-white px-8 py-3 rounded hover:bg-[#002447] transition font-medium inline-block">
                Read More
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-[#001B3D] text-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-5xl font-bold text-[#FF6B35] mb-2">500+</div>
              <div className="text-gray-300">Projects Completed</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-[#FF6B35] mb-2">25+</div>
              <div className="text-gray-300">Years Experience</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-[#FF6B35] mb-2">350+</div>
              <div className="text-gray-300">Happy Clients</div>
            </div>
            <div className="text-center">
              <div className="text-5xl font-bold text-[#FF6B35] mb-2">50+</div>
              <div className="text-gray-300">Expert Team</div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <p className="text-[#FF6B35] mb-2 text-sm uppercase tracking-wide">Our Services</p>
            <h2 className="text-4xl font-bold text-[#001B3D] mb-4">What We Offer</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              We provide comprehensive construction services for residential, commercial, and industrial projects.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            {[
              { 
                img: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=600', 
                title: 'Building Construction',
                desc: 'Complete building construction services from foundation to finishing.'
              },
              { 
                img: 'https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=600', 
                title: 'Renovation & Remodeling',
                desc: 'Transform your existing space with our expert renovation services.'
              },
              { 
                img: 'https://images.unsplash.com/photo-1581094271901-8022df4466f9?w=600', 
                title: 'Architecture Design',
                desc: 'Innovative architectural designs that combine beauty and functionality.'
              }
            ].map((service, index) => (
              <div key={index} className="group relative overflow-hidden rounded-lg shadow-lg">
                <img src={service.img} alt={service.title} className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-500" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent flex flex-col justify-end p-6">
                  <h3 className="text-white text-xl font-bold mb-2">{service.title}</h3>
                  <p className="text-gray-200 text-sm mb-3">{service.desc}</p>
                  <Link to="/services" className="text-[#FF6B35] font-medium flex items-center hover:gap-2 transition-all">
                    Learn More <ArrowRight className="ml-1" size={16} />
                  </Link>
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center">
            <Link to="/services" className="bg-[#FF6B35] text-white px-8 py-3 rounded hover:bg-[#ff5722] transition font-medium inline-block">
              View All Services
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-[#FF6B35]">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row items-center justify-between">
            <div className="text-white mb-6 md:mb-0">
              <h3 className="text-3xl font-bold mb-2">Ready to Start Your Project?</h3>
              <p className="text-white/90">Get in touch with us today for a free consultation and quote.</p>
            </div>
            <Link to="/contact" className="bg-[#001B3D] text-white px-8 py-3 rounded hover:bg-[#002447] transition font-medium">
              Contact Us Now
            </Link>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <p className="text-[#FF6B35] mb-2 text-sm uppercase tracking-wide">Testimonials</p>
            <h2 className="text-4xl font-bold text-[#001B3D]">What Our Clients Say</h2>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { name: 'John Smith', role: 'Homeowner', text: 'Excellent work! The team was professional, timely, and the quality exceeded our expectations.' },
              { name: 'Sarah Johnson', role: 'Business Owner', text: 'Outstanding service from start to finish. Our commercial project was completed on time and within budget.' },
              { name: 'Michael Brown', role: 'Property Developer', text: 'Highly recommend! Their expertise and attention to detail made our project a huge success.' }
            ].map((testimonial, index) => (
              <div key={index} className="bg-white p-6 rounded-lg shadow-lg">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 bg-[#FF6B35] rounded-full flex items-center justify-center text-white font-bold text-xl">
                    {testimonial.name.charAt(0)}
                  </div>
                  <div className="ml-4">
                    <h4 className="font-bold text-[#001B3D]">{testimonial.name}</h4>
                    <p className="text-gray-600 text-sm">{testimonial.role}</p>
                  </div>
                </div>
                <p className="text-gray-600 italic">&ldquo;{testimonial.text}&rdquo;</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Clients Section */}
      <section className="py-12 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-8">
            <h3 className="text-2xl font-bold text-[#001B3D]">We Work For Our Clients</h3>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-8 items-center">
            {[1, 2, 3, 4, 5].map((item) => (
              <div key={item} className="bg-gray-100 rounded-lg p-6 flex items-center justify-center hover:shadow-lg transition">
                <Award className="text-[#FF6B35]" size={48} />
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}

export default Home
