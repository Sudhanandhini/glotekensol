import { useState } from 'react'
import { X } from 'lucide-react'

const Gallery = () => {
  const [selectedImage, setSelectedImage] = useState(null)
  const [selectedCategory, setSelectedCategory] = useState('All')

  const categories = ['All', 'Residential', 'Commercial', 'Industrial', 'Renovation']

  const projects = [
    {
      id: 1,
      title: 'Modern Family Home',
      category: 'Residential',
      img: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800',
      desc: 'Beautiful modern home with contemporary design'
    },
    {
      id: 2,
      title: 'Office Building Complex',
      category: 'Commercial',
      img: 'https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800',
      desc: 'State-of-the-art office building in downtown'
    },
    {
      id: 3,
      title: 'Industrial Warehouse',
      category: 'Industrial',
      img: 'https://images.unsplash.com/photo-1565008576549-57569a49371d?w=800',
      desc: 'Large-scale warehouse facility construction'
    },
    {
      id: 4,
      title: 'Kitchen Renovation',
      category: 'Renovation',
      img: 'https://images.unsplash.com/photo-1556912173-3bb406ef7e77?w=800',
      desc: 'Complete kitchen remodel with modern finishes'
    },
    {
      id: 5,
      title: 'Luxury Villa',
      category: 'Residential',
      img: 'https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800',
      desc: 'Luxurious villa with pool and landscaping'
    },
    {
      id: 6,
      title: 'Shopping Mall',
      category: 'Commercial',
      img: 'https://images.unsplash.com/photo-1519832064427-02742e3bb54d?w=800',
      desc: 'Multi-story shopping complex development'
    },
    {
      id: 7,
      title: 'Manufacturing Plant',
      category: 'Industrial',
      img: 'https://images.unsplash.com/photo-1581094271901-8022df4466f9?w=800',
      desc: 'Advanced manufacturing facility construction'
    },
    {
      id: 8,
      title: 'Bathroom Remodel',
      category: 'Renovation',
      img: 'https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?w=800',
      desc: 'Luxury bathroom renovation project'
    },
    {
      id: 9,
      title: 'Suburban Home',
      category: 'Residential',
      img: 'https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=800',
      desc: 'Classic suburban family home construction'
    },
    {
      id: 10,
      title: 'Retail Store',
      category: 'Commercial',
      img: 'https://images.unsplash.com/photo-1441984904996-e0b6ba687e04?w=800',
      desc: 'Modern retail store interior and exterior'
    },
    {
      id: 11,
      title: 'Bridge Construction',
      category: 'Industrial',
      img: 'https://images.unsplash.com/photo-1513828583688-c52646db42da?w=800',
      desc: 'Highway bridge construction project'
    },
    {
      id: 12,
      title: 'Home Extension',
      category: 'Renovation',
      img: 'https://images.unsplash.com/photo-1503387762-592deb58ef4e?w=800',
      desc: 'Room addition and home expansion'
    }
  ]

  const filteredProjects = selectedCategory === 'All' 
    ? projects 
    : projects.filter(project => project.category === selectedCategory)

  return (
    <div>
      {/* Page Header */}
      <section className="relative h-[300px] bg-cover bg-center" style={{
        backgroundImage: "linear-gradient(rgba(0, 27, 61, 0.8), rgba(0, 27, 61, 0.8)), url('https://images.unsplash.com/photo-1541888946425-d81bb19240f5?w=1600')"
      }}>
        <div className="container mx-auto px-4 h-full flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-5xl font-bold mb-4">Our Gallery</h1>
            <p className="text-xl">Showcasing Our Best Work</p>
          </div>
        </div>
      </section>

      {/* Gallery Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <p className="text-[#FF6B35] mb-2 text-sm uppercase tracking-wide">Portfolio</p>
            <h2 className="text-4xl font-bold text-[#001B3D] mb-4">Our Completed Projects</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Explore our portfolio of successful construction projects across residential, commercial, and industrial sectors.
            </p>
          </div>

          {/* Category Filter */}
          <div className="flex flex-wrap justify-center gap-4 mb-12">
            {categories.map((category) => (
              <button
                key={category}
                onClick={() => setSelectedCategory(category)}
                className={`px-6 py-2 rounded-full font-medium transition ${
                  selectedCategory === category
                    ? 'bg-[#FF6B35] text-white'
                    : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
                }`}
              >
                {category}
              </button>
            ))}
          </div>

          {/* Gallery Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredProjects.map((project) => (
              <div
                key={project.id}
                className="group relative overflow-hidden rounded-lg shadow-lg cursor-pointer"
                onClick={() => setSelectedImage(project)}
              >
                <img
                  src={project.img}
                  alt={project.title}
                  className="w-full h-80 object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
                  <span className="text-[#FF6B35] text-sm font-medium mb-2">{project.category}</span>
                  <h3 className="text-white text-xl font-bold mb-2">{project.title}</h3>
                  <p className="text-gray-200 text-sm">{project.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Image Modal */}
      {selectedImage && (
        <div
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedImage(null)}
        >
          <button
            className="absolute top-4 right-4 text-white hover:text-[#FF6B35] transition"
            onClick={() => setSelectedImage(null)}
          >
            <X size={32} />
          </button>
          <div className="max-w-5xl w-full" onClick={(e) => e.stopPropagation()}>
            <img
              src={selectedImage.img}
              alt={selectedImage.title}
              className="w-full h-auto rounded-lg shadow-2xl"
            />
            <div className="bg-white p-6 rounded-b-lg">
              <span className="text-[#FF6B35] text-sm font-medium">{selectedImage.category}</span>
              <h3 className="text-2xl font-bold text-[#001B3D] mt-2 mb-2">{selectedImage.title}</h3>
              <p className="text-gray-600">{selectedImage.desc}</p>
            </div>
          </div>
        </div>
      )}

      {/* Stats Section */}
      <section className="py-16 bg-[#001B3D] text-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-5xl font-bold text-[#FF6B35] mb-2">500+</div>
              <div className="text-gray-300">Projects Completed</div>
            </div>
            <div>
              <div className="text-5xl font-bold text-[#FF6B35] mb-2">25+</div>
              <div className="text-gray-300">Years Experience</div>
            </div>
            <div>
              <div className="text-5xl font-bold text-[#FF6B35] mb-2">350+</div>
              <div className="text-gray-300">Happy Clients</div>
            </div>
            <div>
              <div className="text-5xl font-bold text-[#FF6B35] mb-2">98%</div>
              <div className="text-gray-300">Client Satisfaction</div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-[#FF6B35]">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold text-white mb-4">
            Want to See Your Project Here?
          </h2>
          <p className="text-xl text-white/90 mb-8">
            Let's discuss how we can bring your construction vision to life.
          </p>
          <a
            href="/contact"
            className="bg-[#001B3D] text-white px-8 py-3 rounded hover:bg-[#002447] transition font-medium inline-block"
          >
            Start Your Project
          </a>
        </div>
      </section>
    </div>
  )
}

export default Gallery
